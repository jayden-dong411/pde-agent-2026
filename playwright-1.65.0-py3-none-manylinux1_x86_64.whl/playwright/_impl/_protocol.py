# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Generated from packages/protocol/spec by scripts/codegen/generate_protocol.py. Do not edit.

from typing import Any, Dict

# The interface that each interface extends.
EXTENDS: Dict[str, str] = {"ElementHandle": "JSHandle"}

# The object and enum types, in the form of the spec.
TYPES: Dict[str, Any] = {
    "AndroidWebView": {
        "type": "object",
        "properties": {"pid": "int", "pkg": "string", "socketName": "string"},
    },
    "AndroidSelector": {
        "type": "object",
        "properties": {
            "checkable": "boolean?",
            "checked": "boolean?",
            "clazz": "string?",
            "clickable": "boolean?",
            "depth": "int?",
            "desc": "string?",
            "enabled": "boolean?",
            "focusable": "boolean?",
            "focused": "boolean?",
            "hasChild": {
                "type": "object?",
                "properties": {"androidSelector": "AndroidSelector"},
            },
            "hasDescendant": {
                "type": "object?",
                "properties": {
                    "androidSelector": "AndroidSelector",
                    "maxDepth": "int?",
                },
            },
            "longClickable": "boolean?",
            "pkg": "string?",
            "res": "string?",
            "scrollable": "boolean?",
            "selected": "boolean?",
            "text": "string?",
        },
    },
    "AndroidElementInfo": {
        "type": "object",
        "properties": {
            "children": {"type": "array?", "items": "AndroidElementInfo"},
            "clazz": "string",
            "desc": "string",
            "res": "string",
            "pkg": "string",
            "text": "string",
            "bounds": "Rect",
            "checkable": "boolean",
            "checked": "boolean",
            "clickable": "boolean",
            "enabled": "boolean",
            "focusable": "boolean",
            "focused": "boolean",
            "longClickable": "boolean",
            "scrollable": "boolean",
            "selected": "boolean",
        },
    },
    "APIResponse": {
        "type": "object",
        "properties": {
            "fetchUid": "string",
            "url": "string",
            "status": "int",
            "statusText": "string",
            "headers": {"type": "array", "items": "NameValue"},
            "securityDetails": "SecurityDetails?",
            "serverAddr": "RemoteAddr?",
            "timing": "ResourceTiming?",
            "responseEndTiming": "float?",
        },
    },
    "Metadata": {
        "type": "object",
        "properties": {
            "location": {
                "type": "object?",
                "properties": {"file": "string", "line": "int?", "column": "int?"},
            },
            "title": "string?",
            "internal": "boolean?",
            "timeout": "float?",
        },
    },
    "ClientSideCallMetadata": {
        "type": "object",
        "properties": {
            "id": "string",
            "stack": {"type": "array?", "items": "StackFrame"},
        },
    },
    "SDKLanguage": {
        "type": "enum",
        "literals": ["javascript", "python", "java", "csharp"],
    },
    "WaitInfo": {
        "type": "object",
        "properties": {
            "waitId": "string",
            "phase": {"type": "enum", "literals": ["before", "after", "log"]},
            "event": "string?",
            "message": "string?",
            "error": "string?",
        },
    },
    "HttpCredentials": {
        "type": "object",
        "properties": {
            "username": "string",
            "password": "string",
            "origin": "string?",
            "send": {"type": "enum?", "literals": ["always", "unauthorized"]},
        },
    },
    "SetNetworkCookie": {
        "type": "object",
        "properties": {
            "name": "string",
            "value": "string",
            "url": "string?",
            "domain": "string?",
            "path": "string?",
            "expires": "float?",
            "httpOnly": "boolean?",
            "secure": "boolean?",
            "sameSite": {"type": "enum?", "literals": ["Strict", "Lax", "None"]},
            "partitionKey": "string?",
            "_crHasCrossSiteAncestor": "boolean?",
        },
    },
    "NetworkCookie": {
        "type": "object",
        "properties": {
            "name": "string",
            "value": "string",
            "domain": "string",
            "path": "string",
            "expires": "float",
            "httpOnly": "boolean",
            "secure": "boolean",
            "sameSite": {"type": "enum", "literals": ["Strict", "Lax", "None"]},
            "partitionKey": "string?",
            "_crHasCrossSiteAncestor": "boolean?",
        },
    },
    "ResourceTiming": {
        "type": "object",
        "properties": {
            "startTime": "float",
            "domainLookupStart": "float",
            "domainLookupEnd": "float",
            "connectStart": "float",
            "secureConnectionStart": "float",
            "connectEnd": "float",
            "requestStart": "float",
            "responseStart": "float",
        },
    },
    "SecurityDetails": {
        "type": "object",
        "properties": {
            "issuer": "string?",
            "protocol": "string?",
            "subjectName": "string?",
            "validFrom": "float?",
            "validTo": "float?",
        },
    },
    "RequestSizes": {
        "type": "object",
        "properties": {
            "requestBodySize": "int",
            "requestHeadersSize": "int",
            "responseBodySize": "int",
            "responseHeadersSize": "int",
        },
    },
    "RemoteAddr": {
        "type": "object",
        "properties": {"ipAddress": "string", "port": "int"},
    },
    "ExpectedTextValue": {
        "type": "object",
        "properties": {
            "string": "string?",
            "regexSource": "string?",
            "regexFlags": "string?",
            "matchSubstring": "boolean?",
            "ignoreCase": "boolean?",
            "normalizeWhiteSpace": "boolean?",
        },
    },
    "SelectorEngine": {
        "type": "object",
        "properties": {
            "name": "string",
            "source": "string",
            "contentScript": "boolean?",
        },
    },
    "FormField": {
        "type": "object",
        "properties": {
            "name": "string",
            "value": "string?",
            "file": {
                "type": "object?",
                "properties": {
                    "name": "string",
                    "mimeType": "string?",
                    "buffer": "binary",
                },
            },
        },
    },
    "LifecycleEvent": {
        "type": "enum",
        "literals": ["load", "domcontentloaded", "networkidle", "commit"],
    },
    "ConsoleMessagesFilter": {"type": "enum", "literals": ["all", "since-navigation"]},
    "RecorderSource": {
        "type": "object",
        "properties": {
            "isRecorded": "boolean",
            "id": "string",
            "label": "string",
            "text": "string",
            "language": "string",
            "highlight": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"line": "int", "type": "string"},
                },
            },
            "revealLine": "int?",
            "group": "string?",
        },
    },
    "IndexedDBDatabase": {
        "type": "object",
        "properties": {
            "name": "string",
            "version": "int",
            "stores": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": "string",
                        "autoIncrement": "boolean",
                        "keyPath": "string?",
                        "keyPathArray": {"type": "array?", "items": "string"},
                        "records": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "key": "json?",
                                    "keyEncoded": "json?",
                                    "value": "json?",
                                    "valueEncoded": "json?",
                                },
                            },
                        },
                        "indexes": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": "string",
                                    "keyPath": "string?",
                                    "keyPathArray": {
                                        "type": "array?",
                                        "items": "string",
                                    },
                                    "multiEntry": "boolean",
                                    "unique": "boolean",
                                },
                            },
                        },
                    },
                },
            },
        },
    },
    "OPFSEntry": {
        "type": "object",
        "properties": {
            "path": "string",
            "type": {"type": "enum", "literals": ["file", "directory"]},
            "base64": "string?",
        },
    },
    "SetOriginStorage": {
        "type": "object",
        "properties": {
            "origin": "string",
            "localStorage": {"type": "array", "items": "NameValue"},
            "indexedDB": {"type": "array?", "items": "IndexedDBDatabase"},
            "opfs": {"type": "array?", "items": "OPFSEntry"},
        },
    },
    "OriginStorage": {
        "type": "object",
        "properties": {
            "origin": "string",
            "localStorage": {"type": "array", "items": "NameValue"},
            "indexedDB": {"type": "array?", "items": "IndexedDBDatabase"},
            "opfs": {"type": "array?", "items": "OPFSEntry"},
        },
    },
    "RecordHarOptions": {
        "type": "object",
        "properties": {
            "content": {"type": "enum?", "literals": ["embed", "attach", "omit"]},
            "mode": {"type": "enum?", "literals": ["full", "minimal"]},
            "urlGlob": "string?",
            "urlRegexSource": "string?",
            "urlRegexFlags": "string?",
            "harPath": "string?",
            "resourcesDir": "string?",
        },
    },
    "SerializedValue": {
        "type": "object",
        "properties": {
            "n": "float?",
            "b": "boolean?",
            "s": "string?",
            "v": {
                "type": "enum?",
                "literals": ["null", "undefined", "NaN", "Infinity", "-Infinity", "-0"],
            },
            "d": "string?",
            "u": "string?",
            "bi": "string?",
            "ta": {
                "type": "object?",
                "properties": {
                    "b": "binary",
                    "k": {
                        "type": "enum",
                        "literals": [
                            "i8",
                            "ui8",
                            "ui8c",
                            "i16",
                            "ui16",
                            "i32",
                            "ui32",
                            "f32",
                            "f64",
                            "bi64",
                            "bui64",
                        ],
                    },
                },
            },
            "e": {
                "type": "object?",
                "properties": {"m": "string", "n": "string", "s": "string"},
            },
            "r": {"type": "object?", "properties": {"p": "string", "f": "string"}},
            "a": {"type": "array?", "items": "SerializedValue"},
            "o": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {"k": "string", "v": "SerializedValue"},
                },
            },
            "h": "int?",
            "fn": "string?",
            "id": "int?",
            "ref": "int?",
        },
    },
    "SerializedArgument": {
        "type": "object",
        "properties": {
            "value": "SerializedValue",
            "handles": {"type": "array", "items": "Channel"},
        },
    },
    "SerializedError": {
        "type": "object",
        "properties": {
            "error": {
                "type": "object?",
                "properties": {
                    "message": "string",
                    "name": "string",
                    "stack": "string?",
                    "code": "string?",
                },
            },
            "value": "SerializedValue?",
        },
    },
    "StackFrame": {
        "type": "object",
        "properties": {
            "file": "string",
            "line": "int",
            "column": "int",
            "function": "string?",
        },
    },
    "VirtualCredential": {
        "type": "object",
        "properties": {
            "id": "string",
            "rpId": "string",
            "userHandle": "string",
            "privateKey": "string",
            "publicKey": "string",
            "signCount": "int",
        },
    },
    "SetVirtualCredential": {
        "type": "object",
        "properties": {
            "id": "string",
            "rpId": "string",
            "userHandle": "string",
            "privateKey": "string",
            "publicKey": "string",
            "signCount": "int?",
        },
    },
    "Point": {"type": "object", "properties": {"x": "float", "y": "float"}},
    "Rect": {
        "type": "object",
        "properties": {"x": "float", "y": "float", "width": "float", "height": "float"},
    },
    "URLPattern": {
        "type": "object",
        "properties": {
            "hash": "string",
            "hostname": "string",
            "password": "string",
            "pathname": "string",
            "port": "string",
            "protocol": "string",
            "search": "string",
            "username": "string",
        },
    },
    "NameValue": {
        "type": "object",
        "properties": {"name": "string", "value": "string"},
    },
}

# The parameters of each command, by interface and method.
COMMANDS: Dict[str, Dict[str, Dict[str, Any]]] = {
    "Android": {
        "devices": {"host": "string?", "port": "int?", "omitDriverInstall": "boolean?"}
    },
    "AndroidSocket": {"write": {"data": "binary"}, "close": {}},
    "AndroidDevice": {
        "wait": {
            "androidSelector": "AndroidSelector",
            "state": {"type": "enum?", "literals": ["gone"]},
        },
        "fill": {"androidSelector": "AndroidSelector", "text": "string"},
        "tap": {"androidSelector": "AndroidSelector", "duration": "float?"},
        "drag": {
            "androidSelector": "AndroidSelector",
            "dest": "Point",
            "speed": "float?",
        },
        "fling": {
            "androidSelector": "AndroidSelector",
            "direction": {"type": "enum", "literals": ["up", "down", "left", "right"]},
            "speed": "float?",
        },
        "longTap": {"androidSelector": "AndroidSelector"},
        "pinchClose": {
            "androidSelector": "AndroidSelector",
            "percent": "float",
            "speed": "float?",
        },
        "pinchOpen": {
            "androidSelector": "AndroidSelector",
            "percent": "float",
            "speed": "float?",
        },
        "scroll": {
            "androidSelector": "AndroidSelector",
            "direction": {"type": "enum", "literals": ["up", "down", "left", "right"]},
            "percent": "float",
            "speed": "float?",
        },
        "swipe": {
            "androidSelector": "AndroidSelector",
            "direction": {"type": "enum", "literals": ["up", "down", "left", "right"]},
            "percent": "float",
            "speed": "float?",
        },
        "info": {"androidSelector": "AndroidSelector"},
        "screenshot": {},
        "inputType": {"text": "string"},
        "inputPress": {"key": "string"},
        "inputTap": {"point": "Point"},
        "inputSwipe": {"segments": {"type": "array", "items": "Point"}, "steps": "int"},
        "inputDrag": {"from": "Point", "to": "Point", "steps": "int"},
        "launchBrowser": {
            "noDefaultViewport": "boolean?",
            "viewport": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "screen": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "ignoreHTTPSErrors": "boolean?",
            "clientCertificates": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "origin": "string",
                        "cert": "binary?",
                        "key": "binary?",
                        "passphrase": "string?",
                        "pfx": "binary?",
                    },
                },
            },
            "javaScriptEnabled": "boolean?",
            "bypassCSP": "boolean?",
            "userAgent": "string?",
            "locale": "string?",
            "timezoneId": "string?",
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            },
            "permissions": {"type": "array?", "items": "string"},
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "offline": "boolean?",
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "deviceScaleFactor": "float?",
            "isMobile": "boolean?",
            "hasTouch": "boolean?",
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "reducedMotion": {
                "type": "enum?",
                "literals": ["reduce", "no-preference", "no-override"],
            },
            "forcedColors": {
                "type": "enum?",
                "literals": ["active", "none", "no-override"],
            },
            "acceptDownloads": {
                "type": "enum?",
                "literals": ["accept", "deny", "internal-browser-default"],
            },
            "contrast": {
                "type": "enum?",
                "literals": ["no-preference", "more", "no-override"],
            },
            "baseURL": "string?",
            "recordVideo": {
                "type": "object?",
                "properties": {
                    "dir": "string?",
                    "size": {
                        "type": "object?",
                        "properties": {"width": "int", "height": "int"},
                    },
                    "fps": "int?",
                    "showActions": {
                        "type": "object?",
                        "properties": {
                            "duration": "float?",
                            "position": {
                                "type": "enum?",
                                "literals": [
                                    "top-left",
                                    "top",
                                    "top-right",
                                    "bottom-left",
                                    "bottom",
                                    "bottom-right",
                                ],
                            },
                            "fontSize": "int?",
                            "cursor": {
                                "type": "enum?",
                                "literals": ["none", "pointer"],
                            },
                            "style": {
                                "type": "object?",
                                "properties": {
                                    "point": "string?",
                                    "highlight": "string?",
                                    "title": "string?",
                                },
                            },
                        },
                    },
                },
            },
            "strictSelectors": "boolean?",
            "serviceWorkers": {"type": "enum?", "literals": ["allow", "block"]},
            "selectorEngines": {"type": "array?", "items": "SelectorEngine"},
            "testIdAttributeName": "string?",
            "pkg": "string?",
            "args": {"type": "array?", "items": "string"},
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
        },
        "open": {"command": "string"},
        "shell": {"command": "string"},
        "installApk": {"file": "binary", "args": {"type": "array?", "items": "string"}},
        "push": {"file": "binary", "path": "string", "mode": "int?"},
        "connectToWebView": {"socketName": "string"},
        "close": {},
    },
    "APIRequestContext": {
        "fetch": {
            "url": "string",
            "encodedParams": "string?",
            "params": {"type": "array?", "items": "NameValue"},
            "method": "string?",
            "headers": {"type": "array?", "items": "NameValue"},
            "postData": "binary?",
            "jsonData": "string?",
            "formData": {"type": "array?", "items": "NameValue"},
            "multipartData": {"type": "array?", "items": "FormField"},
            "failOnStatusCode": "boolean?",
            "ignoreHTTPSErrors": "boolean?",
            "maxRedirects": "int?",
            "maxRetries": "int?",
        },
        "fetchResponseBody": {"fetchUid": "string"},
        "fetchLog": {"fetchUid": "string"},
        "addCookies": {"cookies": {"type": "array", "items": "SetNetworkCookie"}},
        "clearCookies": {
            "name": "string?",
            "nameRegexSource": "string?",
            "nameRegexFlags": "string?",
            "domain": "string?",
            "domainRegexSource": "string?",
            "domainRegexFlags": "string?",
            "path": "string?",
            "pathRegexSource": "string?",
            "pathRegexFlags": "string?",
        },
        "cookies": {"urls": {"type": "array", "items": "string"}},
        "storageState": {"indexedDB": "boolean?", "opfs": "boolean?"},
        "disposeAPIResponse": {"fetchUid": "string"},
        "dispose": {"reason": "string?"},
    },
    "Artifact": {
        "pathAfterFinished": {},
        "saveAs": {"path": "string"},
        "saveAsStream": {},
        "failure": {},
        "stream": {},
        "cancel": {},
        "delete": {},
    },
    "Stream": {"read": {"size": "int?"}, "close": {}},
    "WritableStream": {"write": {"binary": "binary"}, "close": {}},
    "Browser": {
        "startServer": {
            "title": "string",
            "workspaceDir": "string?",
            "metadata": "json?",
            "host": "string?",
            "port": "int?",
        },
        "stopServer": {},
        "close": {"reason": "string?"},
        "killForTests": {},
        "defaultUserAgentForTest": {},
        "newContext": {
            "noDefaultViewport": "boolean?",
            "viewport": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "screen": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "ignoreHTTPSErrors": "boolean?",
            "clientCertificates": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "origin": "string",
                        "cert": "binary?",
                        "key": "binary?",
                        "passphrase": "string?",
                        "pfx": "binary?",
                    },
                },
            },
            "javaScriptEnabled": "boolean?",
            "bypassCSP": "boolean?",
            "userAgent": "string?",
            "locale": "string?",
            "timezoneId": "string?",
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            },
            "permissions": {"type": "array?", "items": "string"},
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "offline": "boolean?",
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "deviceScaleFactor": "float?",
            "isMobile": "boolean?",
            "hasTouch": "boolean?",
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "reducedMotion": {
                "type": "enum?",
                "literals": ["reduce", "no-preference", "no-override"],
            },
            "forcedColors": {
                "type": "enum?",
                "literals": ["active", "none", "no-override"],
            },
            "acceptDownloads": {
                "type": "enum?",
                "literals": ["accept", "deny", "internal-browser-default"],
            },
            "contrast": {
                "type": "enum?",
                "literals": ["no-preference", "more", "no-override"],
            },
            "baseURL": "string?",
            "recordVideo": {
                "type": "object?",
                "properties": {
                    "dir": "string?",
                    "size": {
                        "type": "object?",
                        "properties": {"width": "int", "height": "int"},
                    },
                    "fps": "int?",
                    "showActions": {
                        "type": "object?",
                        "properties": {
                            "duration": "float?",
                            "position": {
                                "type": "enum?",
                                "literals": [
                                    "top-left",
                                    "top",
                                    "top-right",
                                    "bottom-left",
                                    "bottom",
                                    "bottom-right",
                                ],
                            },
                            "fontSize": "int?",
                            "cursor": {
                                "type": "enum?",
                                "literals": ["none", "pointer"],
                            },
                            "style": {
                                "type": "object?",
                                "properties": {
                                    "point": "string?",
                                    "highlight": "string?",
                                    "title": "string?",
                                },
                            },
                        },
                    },
                },
            },
            "strictSelectors": "boolean?",
            "serviceWorkers": {"type": "enum?", "literals": ["allow", "block"]},
            "selectorEngines": {"type": "array?", "items": "SelectorEngine"},
            "testIdAttributeName": "string?",
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
            "storageState": {
                "type": "object?",
                "properties": {
                    "cookies": {"type": "array?", "items": "SetNetworkCookie"},
                    "origins": {"type": "array?", "items": "SetOriginStorage"},
                    "credentials": {"type": "array?", "items": "SetVirtualCredential"},
                },
            },
        },
        "newContextForReuse": {
            "noDefaultViewport": "boolean?",
            "viewport": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "screen": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "ignoreHTTPSErrors": "boolean?",
            "clientCertificates": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "origin": "string",
                        "cert": "binary?",
                        "key": "binary?",
                        "passphrase": "string?",
                        "pfx": "binary?",
                    },
                },
            },
            "javaScriptEnabled": "boolean?",
            "bypassCSP": "boolean?",
            "userAgent": "string?",
            "locale": "string?",
            "timezoneId": "string?",
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            },
            "permissions": {"type": "array?", "items": "string"},
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "offline": "boolean?",
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "deviceScaleFactor": "float?",
            "isMobile": "boolean?",
            "hasTouch": "boolean?",
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "reducedMotion": {
                "type": "enum?",
                "literals": ["reduce", "no-preference", "no-override"],
            },
            "forcedColors": {
                "type": "enum?",
                "literals": ["active", "none", "no-override"],
            },
            "acceptDownloads": {
                "type": "enum?",
                "literals": ["accept", "deny", "internal-browser-default"],
            },
            "contrast": {
                "type": "enum?",
                "literals": ["no-preference", "more", "no-override"],
            },
            "baseURL": "string?",
            "recordVideo": {
                "type": "object?",
                "properties": {
                    "dir": "string?",
                    "size": {
                        "type": "object?",
                        "properties": {"width": "int", "height": "int"},
                    },
                    "fps": "int?",
                    "showActions": {
                        "type": "object?",
                        "properties": {
                            "duration": "float?",
                            "position": {
                                "type": "enum?",
                                "literals": [
                                    "top-left",
                                    "top",
                                    "top-right",
                                    "bottom-left",
                                    "bottom",
                                    "bottom-right",
                                ],
                            },
                            "fontSize": "int?",
                            "cursor": {
                                "type": "enum?",
                                "literals": ["none", "pointer"],
                            },
                            "style": {
                                "type": "object?",
                                "properties": {
                                    "point": "string?",
                                    "highlight": "string?",
                                    "title": "string?",
                                },
                            },
                        },
                    },
                },
            },
            "strictSelectors": "boolean?",
            "serviceWorkers": {"type": "enum?", "literals": ["allow", "block"]},
            "selectorEngines": {"type": "array?", "items": "SelectorEngine"},
            "testIdAttributeName": "string?",
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
            "storageState": {
                "type": "object?",
                "properties": {
                    "cookies": {"type": "array?", "items": "SetNetworkCookie"},
                    "origins": {"type": "array?", "items": "SetOriginStorage"},
                    "credentials": {"type": "array?", "items": "SetVirtualCredential"},
                },
            },
        },
        "disconnectFromReusedContext": {"reason": "string"},
        "newBrowserCDPSession": {},
        "startTracing": {
            "page": "Page?",
            "screenshots": "boolean?",
            "categories": {"type": "array?", "items": "string"},
        },
        "stopTracing": {},
    },
    "BrowserContext": {
        "addCookies": {"cookies": {"type": "array", "items": "SetNetworkCookie"}},
        "addInitScript": {"source": "string"},
        "clearCookies": {
            "name": "string?",
            "nameRegexSource": "string?",
            "nameRegexFlags": "string?",
            "domain": "string?",
            "domainRegexSource": "string?",
            "domainRegexFlags": "string?",
            "path": "string?",
            "pathRegexSource": "string?",
            "pathRegexFlags": "string?",
        },
        "clearPermissions": {},
        "close": {"reason": "string?"},
        "cookies": {"urls": {"type": "array", "items": "string"}},
        "exposeBinding": {"name": "string", "noGlobal": "boolean?"},
        "grantPermissions": {
            "permissions": {"type": "array", "items": "string"},
            "origin": "string?",
        },
        "newPage": {},
        "registerSelectorEngine": {"selectorEngine": "SelectorEngine"},
        "setTestIdAttributeName": {"testIdAttributeName": "string"},
        "setExtraHTTPHeaders": {"headers": {"type": "array", "items": "NameValue"}},
        "setGeolocation": {
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            }
        },
        "setHTTPCredentials": {
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"}
        },
        "setNetworkInterceptionPatterns": {
            "patterns": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "glob": "string?",
                        "regexSource": "string?",
                        "regexFlags": "string?",
                        "urlPattern": "URLPattern?",
                    },
                },
            }
        },
        "setWebSocketInterceptionPatterns": {
            "patterns": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "glob": "string?",
                        "regexSource": "string?",
                        "regexFlags": "string?",
                        "urlPattern": "URLPattern?",
                    },
                },
            }
        },
        "setOffline": {"offline": "boolean"},
        "storageState": {
            "indexedDB": "boolean?",
            "opfs": "boolean?",
            "credentials": "boolean?",
        },
        "setStorageState": {
            "storageState": {
                "type": "object?",
                "properties": {
                    "cookies": {"type": "array?", "items": "SetNetworkCookie"},
                    "origins": {"type": "array?", "items": "SetOriginStorage"},
                    "credentials": {"type": "array?", "items": "SetVirtualCredential"},
                },
            }
        },
        "pause": {},
        "showRecorder": {
            "language": "string?",
            "mode": {"type": "enum?", "literals": ["inspecting", "recording"]},
            "pauseOnNextStatement": "boolean?",
            "testIdAttributeName": "string?",
            "launchOptions": "json?",
            "contextOptions": "json?",
            "device": "string?",
            "saveStorage": "string?",
            "outputFile": "string?",
            "handleSIGINT": "boolean?",
            "omitCallTracking": "boolean?",
        },
        "startRecording": {"language": "string?"},
        "stopRecording": {},
        "exposeConsoleApi": {},
        "newCDPSession": {"page": "Page?", "frame": "Frame?"},
        "createTempFiles": {
            "rootDirName": "string?",
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"name": "string", "lastModifiedMs": "float?"},
                },
            },
        },
        "updateSubscription": {
            "event": {
                "type": "enum",
                "literals": [
                    "console",
                    "dialog",
                    "dialogClosed",
                    "request",
                    "response",
                    "requestFinished",
                    "requestFailed",
                ],
            },
            "enabled": "boolean",
        },
        "clockFastForward": {"ticksNumber": "float?", "ticksString": "string?"},
        "clockInstall": {"timeNumber": "float?", "timeString": "string?"},
        "clockPauseAt": {"timeNumber": "float?", "timeString": "string?"},
        "clockResume": {},
        "clockRunFor": {"ticksNumber": "float?", "ticksString": "string?"},
        "clockSetFixedTime": {"timeNumber": "float?", "timeString": "string?"},
        "clockSetSystemTime": {"timeNumber": "float?", "timeString": "string?"},
        "credentialsInstall": {},
        "credentialsCreate": {
            "rpId": "string",
            "id": "string?",
            "userHandle": "string?",
            "privateKey": "string?",
            "publicKey": "string?",
            "signCount": "int?",
        },
        "credentialsGet": {"rpId": "string?", "id": "string?"},
        "credentialsDelete": {"id": "string"},
    },
    "BrowserType": {
        "launch": {
            "channel": "string?",
            "executablePath": "string?",
            "args": {"type": "array?", "items": "string"},
            "ignoreAllDefaultArgs": "boolean?",
            "ignoreDefaultArgs": {"type": "array?", "items": "string"},
            "handleSIGINT": "boolean?",
            "handleSIGTERM": "boolean?",
            "handleSIGHUP": "boolean?",
            "env": {"type": "array?", "items": "NameValue"},
            "headless": "boolean?",
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
            "downloadsPath": "string?",
            "tracesDir": "string?",
            "artifactsDir": "string?",
            "chromiumSandbox": "boolean?",
            "firefoxUserPrefs": "json?",
            "cdpPort": "int?",
            "slowMo": "float?",
        },
        "launchPersistentContext": {
            "channel": "string?",
            "executablePath": "string?",
            "args": {"type": "array?", "items": "string"},
            "ignoreAllDefaultArgs": "boolean?",
            "ignoreDefaultArgs": {"type": "array?", "items": "string"},
            "handleSIGINT": "boolean?",
            "handleSIGTERM": "boolean?",
            "handleSIGHUP": "boolean?",
            "env": {"type": "array?", "items": "NameValue"},
            "headless": "boolean?",
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
            "downloadsPath": "string?",
            "tracesDir": "string?",
            "artifactsDir": "string?",
            "chromiumSandbox": "boolean?",
            "firefoxUserPrefs": "json?",
            "cdpPort": "int?",
            "noDefaultViewport": "boolean?",
            "viewport": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "screen": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "ignoreHTTPSErrors": "boolean?",
            "clientCertificates": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "origin": "string",
                        "cert": "binary?",
                        "key": "binary?",
                        "passphrase": "string?",
                        "pfx": "binary?",
                    },
                },
            },
            "javaScriptEnabled": "boolean?",
            "bypassCSP": "boolean?",
            "userAgent": "string?",
            "locale": "string?",
            "timezoneId": "string?",
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            },
            "permissions": {"type": "array?", "items": "string"},
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "offline": "boolean?",
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "deviceScaleFactor": "float?",
            "isMobile": "boolean?",
            "hasTouch": "boolean?",
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "reducedMotion": {
                "type": "enum?",
                "literals": ["reduce", "no-preference", "no-override"],
            },
            "forcedColors": {
                "type": "enum?",
                "literals": ["active", "none", "no-override"],
            },
            "acceptDownloads": {
                "type": "enum?",
                "literals": ["accept", "deny", "internal-browser-default"],
            },
            "contrast": {
                "type": "enum?",
                "literals": ["no-preference", "more", "no-override"],
            },
            "baseURL": "string?",
            "recordVideo": {
                "type": "object?",
                "properties": {
                    "dir": "string?",
                    "size": {
                        "type": "object?",
                        "properties": {"width": "int", "height": "int"},
                    },
                    "fps": "int?",
                    "showActions": {
                        "type": "object?",
                        "properties": {
                            "duration": "float?",
                            "position": {
                                "type": "enum?",
                                "literals": [
                                    "top-left",
                                    "top",
                                    "top-right",
                                    "bottom-left",
                                    "bottom",
                                    "bottom-right",
                                ],
                            },
                            "fontSize": "int?",
                            "cursor": {
                                "type": "enum?",
                                "literals": ["none", "pointer"],
                            },
                            "style": {
                                "type": "object?",
                                "properties": {
                                    "point": "string?",
                                    "highlight": "string?",
                                    "title": "string?",
                                },
                            },
                        },
                    },
                },
            },
            "strictSelectors": "boolean?",
            "serviceWorkers": {"type": "enum?", "literals": ["allow", "block"]},
            "selectorEngines": {"type": "array?", "items": "SelectorEngine"},
            "testIdAttributeName": "string?",
            "userDataDir": "string",
            "slowMo": "float?",
        },
        "connectOverCDP": {
            "endpointURL": "string?",
            "headers": {"type": "array?", "items": "NameValue"},
            "slowMo": "float?",
            "isLocal": "boolean?",
            "noDefaults": "boolean?",
            "isWebView": "boolean?",
            "artifactsDir": "string?",
            "transport": "binary?",
        },
        "connectToWorker": {"endpoint": "string"},
    },
    "Disposable": {"dispose": {}},
    "Electron": {
        "launch": {
            "executablePath": "string?",
            "args": {"type": "array?", "items": "string"},
            "chromiumSandbox": "boolean?",
            "cwd": "string?",
            "env": {"type": "array?", "items": "NameValue"},
            "acceptDownloads": {
                "type": "enum?",
                "literals": ["accept", "deny", "internal-browser-default"],
            },
            "bypassCSP": "boolean?",
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "geolocation": {
                "type": "object?",
                "properties": {
                    "longitude": "float",
                    "latitude": "float",
                    "accuracy": "float?",
                },
            },
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "ignoreHTTPSErrors": "boolean?",
            "locale": "string?",
            "offline": "boolean?",
            "recordVideo": {
                "type": "object?",
                "properties": {
                    "dir": "string?",
                    "size": {
                        "type": "object?",
                        "properties": {"width": "int", "height": "int"},
                    },
                    "fps": "int?",
                    "showActions": {
                        "type": "object?",
                        "properties": {
                            "duration": "float?",
                            "position": {
                                "type": "enum?",
                                "literals": [
                                    "top-left",
                                    "top",
                                    "top-right",
                                    "bottom-left",
                                    "bottom",
                                    "bottom-right",
                                ],
                            },
                            "fontSize": "int?",
                            "cursor": {
                                "type": "enum?",
                                "literals": ["none", "pointer"],
                            },
                            "style": {
                                "type": "object?",
                                "properties": {
                                    "point": "string?",
                                    "highlight": "string?",
                                    "title": "string?",
                                },
                            },
                        },
                    },
                },
            },
            "strictSelectors": "boolean?",
            "timezoneId": "string?",
            "tracesDir": "string?",
            "artifactsDir": "string?",
            "selectorEngines": {"type": "array?", "items": "SelectorEngine"},
            "testIdAttributeName": "string?",
        }
    },
    "ElectronApplication": {
        "browserWindow": {"page": "Page"},
        "evaluateExpression": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evaluateExpressionHandle": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "updateSubscription": {
            "event": {"type": "enum", "literals": ["console"]},
            "enabled": "boolean",
        },
    },
    "Frame": {
        "evalOnSelector": {
            "selector": "string",
            "strict": "boolean?",
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evalOnSelectorAll": {
            "selector": "string",
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "addScriptTag": {"url": "string?", "content": "string?", "type": "string?"},
        "addStyleTag": {"url": "string?", "content": "string?"},
        "ariaSnapshot": {
            "mode": {"type": "enum?", "literals": ["ai", "default"]},
            "selector": "string?",
            "depth": "int?",
            "boxes": "boolean?",
        },
        "ariaSnapshotJSON": {
            "mode": {"type": "enum?", "literals": ["ai", "default"]},
            "selector": "string?",
            "depth": "int?",
            "boxes": "boolean?",
        },
        "blur": {"selector": "string", "strict": "boolean?"},
        "check": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "position": "Point?",
            "trial": "boolean?",
        },
        "click": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "noWaitAfter": "boolean?",
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "delay": "float?",
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "clickCount": "int?",
            "trial": "boolean?",
            "steps": "int?",
        },
        "content": {"includeShadow": "boolean?"},
        "dragAndDrop": {
            "source": "string",
            "target": "string",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "trial": "boolean?",
            "sourcePosition": "Point?",
            "targetPosition": "Point?",
            "strict": "boolean?",
            "steps": "int?",
        },
        "drop": {
            "selector": "string",
            "strict": "boolean?",
            "position": "Point?",
            "payloads": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": "string",
                        "mimeType": "string?",
                        "buffer": "binary",
                    },
                },
            },
            "localPaths": {"type": "array?", "items": "string"},
            "streams": {"type": "array?", "items": "WritableStream"},
            "data": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {"mimeType": "string", "value": "string"},
                },
            },
        },
        "dblclick": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "delay": "float?",
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "trial": "boolean?",
            "steps": "int?",
        },
        "dispatchEvent": {
            "selector": "string",
            "strict": "boolean?",
            "type": "string",
            "eventInit": "SerializedArgument",
        },
        "evaluateExpression": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evaluateExpressionHandle": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "fill": {
            "selector": "string",
            "strict": "boolean?",
            "value": "string",
            "force": "boolean?",
        },
        "focus": {"selector": "string", "strict": "boolean?"},
        "frameElement": {},
        "resolveSelector": {"selector": "string", "sdkLanguage": "SDKLanguage?"},
        "highlight": {"selector": "string", "style": "string?"},
        "hideHighlight": {"selector": "string"},
        "getAttribute": {"selector": "string", "strict": "boolean?", "name": "string"},
        "goto": {"url": "string", "waitUntil": "LifecycleEvent?", "referer": "string?"},
        "hover": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "trial": "boolean?",
        },
        "innerHTML": {"selector": "string", "strict": "boolean?"},
        "innerText": {"selector": "string", "strict": "boolean?"},
        "inputValue": {"selector": "string", "strict": "boolean?"},
        "isChecked": {"selector": "string", "strict": "boolean?"},
        "isDisabled": {"selector": "string", "strict": "boolean?"},
        "isEnabled": {"selector": "string", "strict": "boolean?"},
        "isHidden": {"selector": "string", "strict": "boolean?"},
        "isVisible": {"selector": "string", "strict": "boolean?"},
        "isEditable": {"selector": "string", "strict": "boolean?"},
        "press": {
            "selector": "string",
            "strict": "boolean?",
            "key": "string",
            "delay": "float?",
            "noWaitAfter": "boolean?",
        },
        "querySelector": {"selector": "string", "strict": "boolean?"},
        "querySelectorAll": {"selector": "string"},
        "queryCount": {"selector": "string"},
        "selectOption": {
            "selector": "string",
            "strict": "boolean?",
            "elements": {"type": "array?", "items": "ElementHandle"},
            "options": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "valueOrLabel": "string?",
                        "value": "string?",
                        "label": "string?",
                        "index": "int?",
                    },
                },
            },
            "force": "boolean?",
        },
        "setContent": {"html": "string", "waitUntil": "LifecycleEvent?"},
        "setInputFiles": {
            "selector": "string",
            "strict": "boolean?",
            "payloads": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": "string",
                        "mimeType": "string?",
                        "buffer": "binary",
                    },
                },
            },
            "localDirectory": "string?",
            "directoryStream": "WritableStream?",
            "localPaths": {"type": "array?", "items": "string"},
            "streams": {"type": "array?", "items": "WritableStream"},
        },
        "tap": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "trial": "boolean?",
        },
        "textContent": {"selector": "string", "strict": "boolean?"},
        "title": {},
        "type": {
            "selector": "string",
            "strict": "boolean?",
            "text": "string",
            "delay": "float?",
        },
        "uncheck": {
            "selector": "string",
            "strict": "boolean?",
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "position": "Point?",
            "trial": "boolean?",
        },
        "waitForTimeout": {"waitTimeout": "float"},
        "waitForFunction": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
            "pollingInterval": "float?",
            "selector": "string?",
            "strict": "boolean?",
        },
        "waitForSelector": {
            "selector": "string",
            "strict": "boolean?",
            "state": {
                "type": "enum?",
                "literals": ["attached", "detached", "visible", "hidden"],
            },
            "omitReturnValue": "boolean?",
        },
        "expect": {
            "selector": "string?",
            "expression": "string",
            "expressionArg": "json?",
            "pseudo": {"type": "enum?", "literals": ["before", "after"]},
            "expectedText": {"type": "array?", "items": "ExpectedTextValue"},
            "expectedNumber": "float?",
            "expectedValue": "SerializedArgument?",
            "useInnerText": "boolean?",
            "isNot": "boolean",
        },
        "webmcpTools": {},
        "webmcpCallTool": {"name": "string", "input": "SerializedArgument"},
    },
    "JSHandle": {
        "dispose": {},
        "evaluateExpression": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evaluateExpressionHandle": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "getPropertyList": {},
        "getProperty": {"name": "string"},
        "jsonValue": {},
    },
    "ElementHandle": {
        "evalOnSelector": {
            "selector": "string",
            "strict": "boolean?",
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evalOnSelectorAll": {
            "selector": "string",
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "boundingBox": {},
        "check": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "position": "Point?",
            "trial": "boolean?",
        },
        "click": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "noWaitAfter": "boolean?",
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "delay": "float?",
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "clickCount": "int?",
            "trial": "boolean?",
            "steps": "int?",
        },
        "contentFrame": {},
        "dblclick": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "delay": "float?",
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "trial": "boolean?",
            "steps": "int?",
        },
        "dispatchEvent": {"type": "string", "eventInit": "SerializedArgument"},
        "fill": {"value": "string", "force": "boolean?"},
        "focus": {},
        "getAttribute": {"name": "string"},
        "hover": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "trial": "boolean?",
        },
        "innerHTML": {},
        "innerText": {},
        "inputValue": {},
        "isChecked": {},
        "isDisabled": {},
        "isEditable": {},
        "isEnabled": {},
        "isHidden": {},
        "isVisible": {},
        "ownerFrame": {},
        "press": {"key": "string", "delay": "float?", "noWaitAfter": "boolean?"},
        "querySelector": {"selector": "string", "strict": "boolean?"},
        "querySelectorAll": {"selector": "string"},
        "screenshot": {
            "type": {"type": "enum?", "literals": ["png", "jpeg", "webp"]},
            "quality": "int?",
            "omitBackground": "boolean?",
            "caret": {"type": "enum?", "literals": ["hide", "initial"]},
            "animations": {"type": "enum?", "literals": ["disabled", "allow"]},
            "scale": {"type": "enum?", "literals": ["css", "device"]},
            "mask": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {"frame": "Frame", "selector": "string"},
                },
            },
            "maskColor": "string?",
            "style": "string?",
        },
        "scrollIntoViewIfNeeded": {},
        "selectOption": {
            "elements": {"type": "array?", "items": "ElementHandle"},
            "options": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "valueOrLabel": "string?",
                        "value": "string?",
                        "label": "string?",
                        "index": "int?",
                    },
                },
            },
            "force": "boolean?",
        },
        "selectText": {"force": "boolean?"},
        "setInputFiles": {
            "payloads": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": "string",
                        "mimeType": "string?",
                        "buffer": "binary",
                    },
                },
            },
            "localDirectory": "string?",
            "directoryStream": "WritableStream?",
            "localPaths": {"type": "array?", "items": "string"},
            "streams": {"type": "array?", "items": "WritableStream"},
        },
        "tap": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "modifiers": {
                "type": "array?",
                "items": {
                    "type": "enum",
                    "literals": ["Alt", "Control", "ControlOrMeta", "Meta", "Shift"],
                },
            },
            "position": "Point?",
            "trial": "boolean?",
        },
        "textContent": {},
        "type": {"text": "string", "delay": "float?"},
        "uncheck": {
            "force": "boolean?",
            "scroll": {"type": "enum?", "literals": ["auto", "none"]},
            "position": "Point?",
            "trial": "boolean?",
        },
        "waitForElementState": {
            "state": {
                "type": "enum",
                "literals": [
                    "visible",
                    "hidden",
                    "stable",
                    "enabled",
                    "disabled",
                    "editable",
                ],
            }
        },
        "waitForSelector": {
            "selector": "string",
            "strict": "boolean?",
            "state": {
                "type": "enum?",
                "literals": ["attached", "detached", "visible", "hidden"],
            },
        },
    },
    "LocalUtils": {
        "zip": {
            "zipFile": "string",
            "entries": {"type": "array", "items": "NameValue"},
            "stacksId": "string?",
            "mode": {"type": "enum", "literals": ["write", "append"]},
            "includeSources": "boolean",
            "additionalSources": {"type": "array?", "items": "string"},
        },
        "harOpen": {"file": "string"},
        "harLookup": {
            "harId": "string",
            "url": "string",
            "method": "string",
            "headers": {"type": "array", "items": "NameValue"},
            "postData": "binary?",
            "isNavigationRequest": "boolean",
        },
        "harClose": {"harId": "string"},
        "harUnzip": {
            "zipFile": "string",
            "harFile": "string",
            "resourcesDir": "string?",
        },
        "connect": {
            "endpoint": "string",
            "headers": "json?",
            "exposeNetwork": "string?",
            "slowMo": "float?",
            "socksProxyRedirectPortForTest": "int?",
        },
        "tracingStarted": {
            "tracesDir": "string?",
            "traceName": "string",
            "live": "boolean?",
        },
        "addStackToTracingNoReply": {"callData": "ClientSideCallMetadata"},
        "traceDiscarded": {"stacksId": "string"},
        "globToRegex": {
            "glob": "string",
            "baseURL": "string?",
            "webSocketUrl": "boolean?",
        },
        "asLocatorDescription": {"selector": "string", "sdkLanguage": "SDKLanguage"},
    },
    "Request": {"response": {}, "rawRequestHeaders": {}},
    "Route": {
        "redirectNavigationRequest": {"url": "string"},
        "abort": {"errorCode": "string?"},
        "continue": {
            "url": "string?",
            "method": "string?",
            "headers": {"type": "array?", "items": "NameValue"},
            "postData": "binary?",
            "isFallback": "boolean",
        },
        "fulfill": {
            "status": "int?",
            "headers": {"type": "array?", "items": "NameValue"},
            "body": "string?",
            "isBase64": "boolean?",
            "fetchResponseUid": "string?",
        },
    },
    "WebSocketRoute": {
        "connect": {},
        "ensureOpened": {},
        "sendToPage": {"message": "string", "isBase64": "boolean"},
        "sendToServer": {"message": "string", "isBase64": "boolean"},
        "closePage": {"code": "int?", "reason": "string?", "wasClean": "boolean"},
        "closeServer": {"code": "int?", "reason": "string?", "wasClean": "boolean"},
    },
    "Response": {
        "body": {},
        "securityDetails": {},
        "serverAddr": {},
        "rawResponseHeaders": {},
        "httpVersion": {},
        "sizes": {},
    },
    "WebSocket": {},
    "Page": {
        "addInitScript": {"source": "string"},
        "close": {"reason": "string?"},
        "runBeforeUnload": {},
        "clearConsoleMessages": {},
        "consoleMessages": {"filter": "ConsoleMessagesFilter?"},
        "emulateMedia": {
            "media": {"type": "enum?", "literals": ["screen", "print", "no-override"]},
            "colorScheme": {
                "type": "enum?",
                "literals": ["dark", "light", "no-preference", "no-override"],
            },
            "reducedMotion": {
                "type": "enum?",
                "literals": ["reduce", "no-preference", "no-override"],
            },
            "forcedColors": {
                "type": "enum?",
                "literals": ["active", "none", "no-override"],
            },
            "contrast": {
                "type": "enum?",
                "literals": ["no-preference", "more", "no-override"],
            },
        },
        "exposeBinding": {"name": "string", "noGlobal": "boolean?"},
        "goBack": {"waitUntil": "LifecycleEvent?"},
        "goForward": {"waitUntil": "LifecycleEvent?"},
        "requestGC": {},
        "registerLocatorHandler": {"selector": "string", "noWaitAfter": "boolean?"},
        "resolveLocatorHandlerNoReply": {"uid": "int", "remove": "boolean?"},
        "unregisterLocatorHandler": {"uid": "int"},
        "reload": {"waitUntil": "LifecycleEvent?"},
        "expectScreenshot": {
            "expected": "binary?",
            "isNot": "boolean",
            "locator": {
                "type": "object?",
                "properties": {"frame": "Frame", "selector": "string"},
            },
            "comparator": "string?",
            "maxDiffPixels": "int?",
            "maxDiffPixelRatio": "float?",
            "threshold": "float?",
            "fullPage": "boolean?",
            "clip": "Rect?",
            "type": {"type": "enum?", "literals": ["png", "webp"]},
            "omitBackground": "boolean?",
            "caret": {"type": "enum?", "literals": ["hide", "initial"]},
            "animations": {"type": "enum?", "literals": ["disabled", "allow"]},
            "scale": {"type": "enum?", "literals": ["css", "device"]},
            "mask": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {"frame": "Frame", "selector": "string"},
                },
            },
            "maskColor": "string?",
            "style": "string?",
        },
        "screenshot": {
            "type": {"type": "enum?", "literals": ["png", "jpeg", "webp"]},
            "quality": "int?",
            "fullPage": "boolean?",
            "clip": "Rect?",
            "omitBackground": "boolean?",
            "caret": {"type": "enum?", "literals": ["hide", "initial"]},
            "animations": {"type": "enum?", "literals": ["disabled", "allow"]},
            "scale": {"type": "enum?", "literals": ["css", "device"]},
            "mask": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {"frame": "Frame", "selector": "string"},
                },
            },
            "maskColor": "string?",
            "style": "string?",
        },
        "setExtraHTTPHeaders": {"headers": {"type": "array", "items": "NameValue"}},
        "setNetworkInterceptionPatterns": {
            "patterns": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "glob": "string?",
                        "regexSource": "string?",
                        "regexFlags": "string?",
                        "urlPattern": "URLPattern?",
                    },
                },
            }
        },
        "setWebSocketInterceptionPatterns": {
            "patterns": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "glob": "string?",
                        "regexSource": "string?",
                        "regexFlags": "string?",
                        "urlPattern": "URLPattern?",
                    },
                },
            }
        },
        "setViewportSize": {
            "viewportSize": {
                "type": "object",
                "properties": {"width": "int", "height": "int"},
            }
        },
        "keyboardDown": {"key": "string"},
        "keyboardUp": {"key": "string"},
        "keyboardInsertText": {"text": "string"},
        "keyboardType": {"text": "string", "delay": "float?"},
        "keyboardPress": {"key": "string", "delay": "float?"},
        "mouseMove": {"x": "float", "y": "float", "steps": "int?"},
        "mouseDown": {
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "clickCount": "int?",
        },
        "mouseUp": {
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "clickCount": "int?",
        },
        "mouseClick": {
            "x": "float",
            "y": "float",
            "delay": "float?",
            "button": {"type": "enum?", "literals": ["left", "right", "middle"]},
            "clickCount": "int?",
        },
        "mouseWheel": {"deltaX": "float", "deltaY": "float"},
        "touchscreenTap": {"x": "float", "y": "float"},
        "clearPageErrors": {},
        "pageErrors": {"filter": "ConsoleMessagesFilter?"},
        "pdf": {
            "scale": "float?",
            "displayHeaderFooter": "boolean?",
            "headerTemplate": "string?",
            "footerTemplate": "string?",
            "printBackground": "boolean?",
            "landscape": "boolean?",
            "pageRanges": "string?",
            "format": "string?",
            "width": "string?",
            "height": "string?",
            "preferCSSPageSize": "boolean?",
            "margin": {
                "type": "object?",
                "properties": {
                    "top": "string?",
                    "bottom": "string?",
                    "left": "string?",
                    "right": "string?",
                },
            },
            "tagged": "boolean?",
            "outline": "boolean?",
        },
        "requests": {},
        "startJSCoverage": {
            "resetOnNavigation": "boolean?",
            "reportAnonymousScripts": "boolean?",
        },
        "stopJSCoverage": {},
        "startCSSCoverage": {"resetOnNavigation": "boolean?"},
        "stopCSSCoverage": {},
        "bringToFront": {},
        "pickLocator": {},
        "cancelPickLocator": {},
        "hideHighlight": {},
        "screencastShowOverlay": {"html": "string", "duration": "float?"},
        "screencastRemoveOverlay": {"id": "string"},
        "screencastChapter": {
            "title": "string",
            "description": "string?",
            "duration": "float?",
        },
        "screencastSetOverlayVisible": {"visible": "boolean"},
        "screencastShowActions": {
            "duration": "float?",
            "position": {
                "type": "enum?",
                "literals": [
                    "top-left",
                    "top",
                    "top-right",
                    "bottom-left",
                    "bottom",
                    "bottom-right",
                ],
            },
            "fontSize": "int?",
            "cursor": {"type": "enum?", "literals": ["none", "pointer"]},
            "style": {
                "type": "object?",
                "properties": {
                    "point": "string?",
                    "highlight": "string?",
                    "title": "string?",
                },
            },
        },
        "screencastHideActions": {},
        "screencastStart": {
            "size": {
                "type": "object?",
                "properties": {"width": "int", "height": "int"},
            },
            "quality": "int?",
            "fps": "int?",
            "sendFrames": "boolean?",
            "record": "boolean?",
        },
        "screencastFrameAck": {"frameId": "int"},
        "screencastStop": {},
        "updateSubscription": {
            "event": {
                "type": "enum",
                "literals": [
                    "console",
                    "dialog",
                    "dialogClosed",
                    "fileChooser",
                    "request",
                    "response",
                    "requestFinished",
                    "requestFailed",
                ],
            },
            "enabled": "boolean",
        },
        "setDockTile": {"image": "binary"},
        "webStorageItems": {"kind": {"type": "enum", "literals": ["local", "session"]}},
        "webStorageGetItem": {
            "kind": {"type": "enum", "literals": ["local", "session"]},
            "name": "string",
        },
        "webStorageSetItem": {
            "kind": {"type": "enum", "literals": ["local", "session"]},
            "name": "string",
            "value": "string",
        },
        "webStorageRemoveItem": {
            "kind": {"type": "enum", "literals": ["local", "session"]},
            "name": "string",
        },
        "webStorageClear": {"kind": {"type": "enum", "literals": ["local", "session"]}},
    },
    "Root": {
        "initialize": {
            "sdkLanguage": "SDKLanguage",
            "supportsLoneSurrogates": "boolean?",
        }
    },
    "Playwright": {
        "newRequest": {
            "baseURL": "string?",
            "userAgent": "string?",
            "ignoreHTTPSErrors": "boolean?",
            "extraHTTPHeaders": {"type": "array?", "items": "NameValue"},
            "failOnStatusCode": "boolean?",
            "clientCertificates": {
                "type": "array?",
                "items": {
                    "type": "object",
                    "properties": {
                        "origin": "string",
                        "cert": "binary?",
                        "key": "binary?",
                        "passphrase": "string?",
                        "pfx": "binary?",
                    },
                },
            },
            "maxRedirects": "int?",
            "httpCredentials": {"type": "array?", "items": "HttpCredentials"},
            "proxy": {
                "type": "object?",
                "properties": {
                    "server": "string",
                    "bypass": "string?",
                    "username": "string?",
                    "password": "string?",
                },
            },
            "storageState": {
                "type": "object?",
                "properties": {
                    "cookies": {"type": "array?", "items": "NetworkCookie"},
                    "origins": {"type": "array?", "items": "SetOriginStorage"},
                },
            },
            "tracesDir": "string?",
        }
    },
    "DebugController": {
        "initialize": {"codegenId": "string", "sdkLanguage": "SDKLanguage"},
        "setReportStateChanged": {"enabled": "boolean"},
        "setRecorderMode": {
            "mode": {"type": "enum", "literals": ["inspecting", "recording", "none"]},
            "testIdAttributeName": "string?",
            "generateAutoExpect": "boolean?",
        },
        "highlight": {"selector": "string?", "ariaTemplate": "string?"},
        "hideHighlight": {},
        "resume": {},
        "kill": {},
    },
    "SocksSupport": {
        "socksConnected": {"uid": "string", "host": "string", "port": "int"},
        "socksFailed": {"uid": "string", "errorCode": "string"},
        "socksData": {"uid": "string", "data": "binary"},
        "socksError": {"uid": "string", "error": "string"},
        "socksEnd": {"uid": "string"},
    },
    "JsonPipe": {"send": {"message": "json"}, "close": {}},
    "CDPSession": {"send": {"method": "string", "params": "json?"}, "detach": {}},
    "BindingCall": {
        "reject": {"error": "SerializedError"},
        "resolve": {"result": "SerializedArgument"},
    },
    "Debugger": {
        "requestPause": {},
        "resume": {},
        "next": {},
        "runTo": {
            "location": {
                "type": "object",
                "properties": {"file": "string", "line": "int?", "column": "int?"},
            }
        },
        "enable": {},
    },
    "Dialog": {"accept": {"promptText": "string?"}, "dismiss": {}},
    "Tracing": {
        "tracingStart": {
            "name": "string?",
            "snapshotDom": "boolean?",
            "snapshotAria": "boolean?",
            "snapshotScreen": "boolean?",
            "screencast": "boolean?",
            "coverage": "boolean?",
            "live": "boolean?",
        },
        "tracingStartChunk": {"name": "string?", "title": "string?"},
        "tracingGroup": {
            "name": "string",
            "location": {
                "type": "object?",
                "properties": {"file": "string", "line": "int?", "column": "int?"},
            },
        },
        "tracingGroupEnd": {},
        "tracingStopChunk": {
            "mode": {"type": "enum", "literals": ["archive", "discard", "entries"]}
        },
        "tracingStop": {},
        "harStart": {"page": "Page?", "options": "RecordHarOptions"},
        "harExport": {
            "harId": "string?",
            "mode": {"type": "enum", "literals": ["archive", "entries"]},
        },
    },
    "Worker": {
        "disconnect": {"reason": "string?"},
        "evaluateExpression": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "evaluateExpressionHandle": {
            "expression": "string",
            "isFunction": "boolean?",
            "arg": "SerializedArgument",
        },
        "updateSubscription": {
            "event": {"type": "enum", "literals": ["console"]},
            "enabled": "boolean",
        },
    },
}
