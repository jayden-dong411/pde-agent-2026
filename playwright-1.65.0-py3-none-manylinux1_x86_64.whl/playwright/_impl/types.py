# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Port of packages/playwright-core/src/client/types.ts.

Python: the types of the public API are the TypedDicts in
playwright/_impl/_api_structures.py, generated from the docs, and the internal ones
are in internal_structures.py. Only the values of types.ts are ported here.
"""

from typing import Set

LIFECYCLE_EVENTS: Set[str] = {"load", "domcontentloaded", "networkidle", "commit"}
